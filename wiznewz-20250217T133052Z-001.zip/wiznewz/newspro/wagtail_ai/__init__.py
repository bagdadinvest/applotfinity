default_app_config = "wagtail_ai.apps.WagtailAiAppConfig"


VERSION = (2, 1, 0)
__version__ = ".".join(map(str, VERSION))
