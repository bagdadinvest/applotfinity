COLLECTION_NAME = "Wagtail Word"
